import { BsCheck2 } from "react-icons/bs";

export function PaymentModal3() {
    return (
        <>
            <div className="pMC_box3">
                <div className="pMCB3_content">
                    <div className="pMCB3C_icon">
                        <span><BsCheck2 /></span>
                    </div>
                    <h2>Success</h2>
                </div>
            </div>
        </>
    )
}